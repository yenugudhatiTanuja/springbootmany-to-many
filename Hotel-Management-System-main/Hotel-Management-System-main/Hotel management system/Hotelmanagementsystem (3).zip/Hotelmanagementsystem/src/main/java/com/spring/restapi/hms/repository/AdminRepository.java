package com.spring.restapi.hms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.restapi.hms.model.Admin;

public interface AdminRepository extends JpaRepository<Admin,Integer>{

}
